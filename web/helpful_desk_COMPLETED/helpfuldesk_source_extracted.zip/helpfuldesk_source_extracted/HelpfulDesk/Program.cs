﻿// Decompiled with JetBrains decompiler
// Type: Program
// Assembly: HelpfulDesk, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 493C75FD-F008-4902-AD1A-3BAC4993AB49
// Assembly location: Y:\huntress2024\web\helpful_desk\helpfuldesk-1.1\HelpfulDesk.dll

using HelpfulDesk.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.IO;

#nullable enable
WebApplicationBuilder builder = WebApplication.CreateBuilder(args);
MvcServiceCollectionExtensions.AddControllersWithViews(builder.Services);
MemoryCacheServiceCollectionExtensions.AddDistributedMemoryCache(builder.Services);
SessionServiceCollectionExtensions.AddSession(builder.Services, (Action<SessionOptions>) (options =>
{
  options.IdleTimeout = TimeSpan.FromMinutes(30.0);
  options.Cookie.HttpOnly = true;
  options.Cookie.IsEssential = true;
}));
ServiceCollectionServiceExtensions.AddScoped<ClientService>(builder.Services);
HttpServiceCollectionExtensions.AddHttpContextAccessor(builder.Services);
ServiceCollectionServiceExtensions.AddScoped<AuthenticationService>(builder.Services);
WebApplication app = builder.Build();
if (!HostEnvironmentEnvExtensions.IsDevelopment(app.Environment))
{
  ExceptionHandlerExtensions.UseExceptionHandler(app, "/Home/Error");
  HstsBuilderExtensions.UseHsts(app);
}
HttpsPolicyBuilderExtensions.UseHttpsRedirection(app);
StaticFileExtensions.UseStaticFiles(app, new StaticFileOptions()
{
  OnPrepareResponse = (Action<StaticFileResponseContext>) (ctx =>
  {
    if (!ctx.File.PhysicalPath.Contains(Path.Combine(app.Environment.WebRootPath, "restricted"), StringComparison.OrdinalIgnoreCase))
      return;
    ctx.Context.Response.StatusCode = 404;
    ctx.Context.Response.ContentLength = new long?(0L);
    ctx.Context.Response.Body = Stream.Null;
    ctx.Context.Response.Body.Flush();
  })
});
EndpointRoutingApplicationBuilderExtensions.UseRouting(app);
SessionMiddlewareExtensions.UseSession(app);
AuthorizationAppBuilderExtensions.UseAuthorization(app);
ControllerEndpointRouteBuilderExtensions.MapControllerRoute(app, "default", "{controller=Home}/{action=Index}/{id?}");
app.Run();
