﻿// Decompiled with JetBrains decompiler
// Type: AspNetCoreGeneratedDocument.Views_Shared__ValidationScriptsPartial
// Assembly: HelpfulDesk, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 493C75FD-F008-4902-AD1A-3BAC4993AB49
// Assembly location: Y:\huntress2024\web\helpful_desk\helpfuldesk-1.1\HelpfulDesk.dll

using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Mvc.Razor.Internal;
using Microsoft.AspNetCore.Mvc.Razor.TagHelpers;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.Hosting;
using Microsoft.AspNetCore.Razor.Runtime.TagHelpers;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Runtime.CompilerServices;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

#nullable enable
namespace AspNetCoreGeneratedDocument
{
  [RazorCompiledItemMetadata("Identifier", "/Views/Shared/_ValidationScriptsPartial.cshtml")]
  [CreateNewOnMetadataUpdate]
  internal sealed class Views_Shared__ValidationScriptsPartial : RazorPage<object>
  {
    private static readonly 
    #nullable disable
    TagHelperAttribute __tagHelperAttribute_0 = new TagHelperAttribute("src", (object) new HtmlString("~/lib/jquery-validation/dist/jquery.validate.min.js"), HtmlAttributeValueStyle.DoubleQuotes);
    private static readonly TagHelperAttribute __tagHelperAttribute_1 = new TagHelperAttribute("src", (object) new HtmlString("~/lib/jquery-validation-unobtrusive/jquery.validate.unobtrusive.min.js"), HtmlAttributeValueStyle.DoubleQuotes);
    private TagHelperExecutionContext __tagHelperExecutionContext;
    private TagHelperRunner __tagHelperRunner = new TagHelperRunner();
    private string __tagHelperStringValueBuffer;
    private TagHelperScopeManager __backed__tagHelperScopeManager;
    private UrlResolutionTagHelper __Microsoft_AspNetCore_Mvc_Razor_TagHelpers_UrlResolutionTagHelper;

    private TagHelperScopeManager __tagHelperScopeManager
    {
      get
      {
        if (this.__backed__tagHelperScopeManager == null)
          this.__backed__tagHelperScopeManager = new TagHelperScopeManager(new Action<HtmlEncoder>(((RazorPageBase) this).StartTagHelperWritingScope), new Func<TagHelperContent>(((RazorPageBase) this).EndTagHelperWritingScope));
        return this.__backed__tagHelperScopeManager;
      }
    }

    public override async Task ExecuteAsync()
    {
      Views_Shared__ValidationScriptsPartial validationScriptsPartial = this;
      validationScriptsPartial.__tagHelperExecutionContext = validationScriptsPartial.__tagHelperScopeManager.Begin("script", TagMode.StartTagAndEndTag, "9ef82fee87759dfecf2638af263085e669aa14a40c723d556d790d65a525ba114004", (Func<Task>) (async () => { }));
      validationScriptsPartial.__Microsoft_AspNetCore_Mvc_Razor_TagHelpers_UrlResolutionTagHelper = validationScriptsPartial.CreateTagHelper<UrlResolutionTagHelper>();
      validationScriptsPartial.__tagHelperExecutionContext.Add((ITagHelper) validationScriptsPartial.__Microsoft_AspNetCore_Mvc_Razor_TagHelpers_UrlResolutionTagHelper);
      validationScriptsPartial.__tagHelperExecutionContext.AddHtmlAttribute(Views_Shared__ValidationScriptsPartial.__tagHelperAttribute_0);
      await validationScriptsPartial.__tagHelperRunner.RunAsync(validationScriptsPartial.__tagHelperExecutionContext);
      if (!validationScriptsPartial.__tagHelperExecutionContext.Output.IsContentModified)
        await validationScriptsPartial.__tagHelperExecutionContext.SetOutputContentAsync();
      validationScriptsPartial.Write((object) validationScriptsPartial.__tagHelperExecutionContext.Output);
      validationScriptsPartial.__tagHelperExecutionContext = validationScriptsPartial.__tagHelperScopeManager.End();
      validationScriptsPartial.WriteLiteral("\r\n");
      validationScriptsPartial.__tagHelperExecutionContext = validationScriptsPartial.__tagHelperScopeManager.Begin("script", TagMode.StartTagAndEndTag, "9ef82fee87759dfecf2638af263085e669aa14a40c723d556d790d65a525ba115067", (Func<Task>) (async () => { }));
      validationScriptsPartial.__Microsoft_AspNetCore_Mvc_Razor_TagHelpers_UrlResolutionTagHelper = validationScriptsPartial.CreateTagHelper<UrlResolutionTagHelper>();
      validationScriptsPartial.__tagHelperExecutionContext.Add((ITagHelper) validationScriptsPartial.__Microsoft_AspNetCore_Mvc_Razor_TagHelpers_UrlResolutionTagHelper);
      validationScriptsPartial.__tagHelperExecutionContext.AddHtmlAttribute(Views_Shared__ValidationScriptsPartial.__tagHelperAttribute_1);
      await validationScriptsPartial.__tagHelperRunner.RunAsync(validationScriptsPartial.__tagHelperExecutionContext);
      if (!validationScriptsPartial.__tagHelperExecutionContext.Output.IsContentModified)
        await validationScriptsPartial.__tagHelperExecutionContext.SetOutputContentAsync();
      validationScriptsPartial.Write((object) validationScriptsPartial.__tagHelperExecutionContext.Output);
      validationScriptsPartial.__tagHelperExecutionContext = validationScriptsPartial.__tagHelperScopeManager.End();
      validationScriptsPartial.WriteLiteral("\r\n");
    }

    [RazorInject]
    public 
    #nullable enable
    IModelExpressionProvider ModelExpressionProvider { get; private set; }

    [RazorInject]
    public IUrlHelper Url { get; private set; }

    [RazorInject]
    public IViewComponentHelper Component { get; private set; }

    [RazorInject]
    public IJsonHelper Json { get; private set; }

    [RazorInject]
    public IHtmlHelper<object> Html { get; private set; }
  }
}
