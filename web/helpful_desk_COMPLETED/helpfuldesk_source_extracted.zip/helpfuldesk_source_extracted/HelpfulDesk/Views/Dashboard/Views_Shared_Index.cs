﻿// Decompiled with JetBrains decompiler
// Type: AspNetCoreGeneratedDocument.Views_Shared_Index
// Assembly: HelpfulDesk, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 493C75FD-F008-4902-AD1A-3BAC4993AB49
// Assembly location: Y:\huntress2024\web\helpful_desk\helpfuldesk-1.1\HelpfulDesk.dll

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Mvc.Razor.Internal;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.Hosting;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

#nullable enable
namespace AspNetCoreGeneratedDocument
{
  [RazorCompiledItemMetadata("Identifier", "/Views/Shared/Index.cshtml")]
  [CreateNewOnMetadataUpdate]
  internal sealed class Views_Shared_Index : RazorPage<object>
  {
    public override async 
    #nullable disable
    Task ExecuteAsync()
    {
    }

    [RazorInject]
    public 
    #nullable enable
    IModelExpressionProvider ModelExpressionProvider { get; private set; }

    [RazorInject]
    public IUrlHelper Url { get; private set; }

    [RazorInject]
    public IViewComponentHelper Component { get; private set; }

    [RazorInject]
    public IJsonHelper Json { get; private set; }

    [RazorInject]
    public IHtmlHelper<object> Html { get; private set; }
  }
}
