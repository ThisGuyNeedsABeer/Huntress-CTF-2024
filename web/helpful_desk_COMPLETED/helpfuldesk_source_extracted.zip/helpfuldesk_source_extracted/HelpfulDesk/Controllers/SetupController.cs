﻿// Decompiled with JetBrains decompiler
// Type: HelpfulDesk.Controllers.SetupController
// Assembly: HelpfulDesk, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 493C75FD-F008-4902-AD1A-3BAC4993AB49
// Assembly location: Y:\huntress2024\web\helpful_desk\helpfuldesk-1.1\HelpfulDesk.dll

using HelpfulDesk.Models;
using HelpfulDesk.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

#nullable enable
namespace HelpfulDesk.Controllers
{
  public class SetupController : Controller
  {
    private readonly string _credsFilePath = "credentials.json";

    public IActionResult SetupWizard()
    {
      if (!System.IO.File.Exists(this._credsFilePath) || !this.HttpContext.Request.Path.Value.Equals("/Setup/SetupWizard", StringComparison.OrdinalIgnoreCase))
        return (IActionResult) this.View();
      return (IActionResult) this.View("Error", (object) new ErrorViewModel()
      {
        RequestId = "Server already set up.",
        ExceptionMessage = "Server already set up.",
        StatusCode = 403
      });
    }

    [HttpPost]
    public IActionResult SetupWizard(string username, string password)
    {
      System.IO.File.WriteAllText(Path.Combine(Directory.GetCurrentDirectory(), "credentials.json"), JsonSerializer.Serialize<List<AuthenticationService.UserCredentials>>(new List<AuthenticationService.UserCredentials>()
      {
        new AuthenticationService.UserCredentials()
        {
          Username = username,
          Password = password,
          IsAdmin = true
        }
      }));
      return (IActionResult) this.RedirectToAction("SetupComplete");
    }

    public IActionResult SetupComplete() => (IActionResult) this.View();
  }
}
