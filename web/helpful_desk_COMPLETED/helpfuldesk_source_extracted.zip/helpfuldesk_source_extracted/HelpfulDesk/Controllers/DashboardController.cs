﻿// Decompiled with JetBrains decompiler
// Type: HelpfulDesk.Controllers.DashboardController
// Assembly: HelpfulDesk, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 493C75FD-F008-4902-AD1A-3BAC4993AB49
// Assembly location: Y:\huntress2024\web\helpful_desk\helpfuldesk-1.1\HelpfulDesk.dll

using HelpfulDesk.Models;
using HelpfulDesk.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CSharp.RuntimeBinder;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;

#nullable enable
namespace HelpfulDesk.Controllers
{
  public class DashboardController : Controller
  {
    private readonly ClientService _clientService;
    private readonly IWebHostEnvironment _env;

    public DashboardController(IWebHostEnvironment env, ClientService clientService)
    {
      this._env = env;
      this._clientService = clientService;
    }

    [HttpPost]
    public IActionResult Login(string username, string password)
    {
      List<AuthenticationService.UserCredentials> source = JsonSerializer.Deserialize<List<AuthenticationService.UserCredentials>>(System.IO.File.ReadAllText(Path.Combine(Directory.GetCurrentDirectory(), "credentials.json")));
      AuthenticationService.UserCredentials userCredentials = source != null ? source.FirstOrDefault<AuthenticationService.UserCredentials>((Func<AuthenticationService.UserCredentials, bool>) (x => x.Username == username && x.Password == password)) : (AuthenticationService.UserCredentials) null;
      if (userCredentials != null)
      {
        this.HttpContext.Session.SetString("UserSession", username);
        if (userCredentials.IsAdmin)
          this.HttpContext.Session.SetString("IsAdmin", "true");
        return (IActionResult) this.RedirectToAction("Index", "Dashboard");
      }
      // ISSUE: reference to a compiler-generated field
      if (DashboardController.\u003C\u003Eo__3.\u003C\u003Ep__0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        DashboardController.\u003C\u003Eo__3.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, string, object>>.Create(Binder.SetMember(CSharpBinderFlags.None, "ErrorMessage", typeof (DashboardController), (IEnumerable<CSharpArgumentInfo>) new CSharpArgumentInfo[2]
        {
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, (string) null),
          CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, (string) null)
        }));
      }
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      object obj = DashboardController.\u003C\u003Eo__3.\u003C\u003Ep__0.Target((CallSite) DashboardController.\u003C\u003Eo__3.\u003C\u003Ep__0, this.ViewBag, "Invalid credentials.");
      return (IActionResult) this.View();
    }

    public IActionResult ClientFiles(string clientId)
    {
      Client clientById = this._clientService.GetClientById(clientId);
      return clientById == null ? (IActionResult) this.NotFound() : (IActionResult) this.View((object) clientById);
    }

    private string RenderFiles(List<FileItem> files, string indent = "")
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("<ul>");
      foreach (FileItem file in files)
      {
        if (file.IsDirectory)
        {
          stringBuilder.AppendFormat("<li><strong>{0}/</strong></li>", (object) file.Name);
          stringBuilder.Append(this.RenderFiles(file.Children, indent + "&nbsp;&nbsp;&nbsp;&nbsp;"));
        }
        else
          stringBuilder.AppendFormat("<li>{0}</li>", (object) file.Name);
      }
      stringBuilder.Append("</ul>");
      return stringBuilder.ToString();
    }

    public IActionResult GetFileSystem(string clientId)
    {
      Client clientById = this._clientService.GetClientById(clientId);
      return clientById == null ? (IActionResult) this.NotFound() : (IActionResult) this.Json((object) clientById.Filesystem);
    }

    public IActionResult DownloadFile(string fileName)
    {
      string str1 = this.HttpContext.Session.GetString("IsAdmin");
      if (str1 == null || !str1.Equals("true", StringComparison.OrdinalIgnoreCase))
        return (IActionResult) this.RedirectToAction("AccessDenied", "Error");
      string str2 = Path.Combine(Path.Combine(this._env.WebRootPath, "restricted"), fileName);
      if (!System.IO.File.Exists(str2))
        return (IActionResult) this.NotFound();
      string contentType = "application/octet-stream";
      return (IActionResult) this.PhysicalFile(str2, contentType, Path.GetFileName(str2));
    }

    public IActionResult Index()
    {
      string str = this.HttpContext.Session.GetString("IsAdmin");
      return str == null || !str.Equals("True", StringComparison.OrdinalIgnoreCase) ? (IActionResult) this.RedirectToAction(nameof (Index), "Home") : (IActionResult) this.View((object) this._clientService.GetClients());
    }
  }
}
