﻿// Decompiled with JetBrains decompiler
// Type: HelpfulDesk.Controllers.AccountController
// Assembly: HelpfulDesk, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 493C75FD-F008-4902-AD1A-3BAC4993AB49
// Assembly location: Y:\huntress2024\web\helpful_desk\helpfuldesk-1.1\HelpfulDesk.dll

using HelpfulDesk.Services;
using Microsoft.AspNetCore.Mvc;

#nullable enable
namespace HelpfulDesk.Controllers
{
  public class AccountController : Controller
  {
    private readonly AuthenticationService _authService;

    public AccountController(AuthenticationService authService) => this._authService = authService;

    public IActionResult Logout()
    {
      this.HttpContext.Session.Clear();
      return (IActionResult) this.RedirectToAction("Index", "Home");
    }
  }
}
