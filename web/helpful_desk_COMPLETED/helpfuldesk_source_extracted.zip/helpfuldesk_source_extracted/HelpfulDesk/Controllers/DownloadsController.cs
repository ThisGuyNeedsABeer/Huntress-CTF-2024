﻿// Decompiled with JetBrains decompiler
// Type: HelpfulDesk.Controllers.DownloadsController
// Assembly: HelpfulDesk, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 493C75FD-F008-4902-AD1A-3BAC4993AB49
// Assembly location: Y:\huntress2024\web\helpful_desk\helpfuldesk-1.1\HelpfulDesk.dll

using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System.IO;

#nullable enable
namespace HelpfulDesk.Controllers
{
  [ApiController]
  [Route("api/v1/downloads")]
  public class DownloadsController : ControllerBase
  {
    private readonly IWebHostEnvironment _env;

    public DownloadsController(IWebHostEnvironment env) => this._env = env;

    [HttpGet("{fileName}")]
    public IActionResult DownloadFile(string fileName)
    {
      string str = Path.Combine(Path.Combine(this._env.WebRootPath, "downloads"), fileName);
      return !System.IO.File.Exists(str) ? (IActionResult) this.NotFound() : (IActionResult) this.PhysicalFile(str, "application/octet-stream", Path.GetFileName(str));
    }
  }
}
