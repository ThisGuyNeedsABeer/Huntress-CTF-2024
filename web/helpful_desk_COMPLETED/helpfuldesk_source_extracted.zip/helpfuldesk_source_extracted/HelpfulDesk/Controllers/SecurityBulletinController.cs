﻿// Decompiled with JetBrains decompiler
// Type: HelpfulDesk.Controllers.SecurityController
// Assembly: HelpfulDesk, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 493C75FD-F008-4902-AD1A-3BAC4993AB49
// Assembly location: Y:\huntress2024\web\helpful_desk\helpfuldesk-1.1\HelpfulDesk.dll

using HelpfulDesk.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

#nullable enable
namespace HelpfulDesk.Controllers
{
  public class SecurityController : Controller
  {
    public IActionResult Bulletin()
    {
      return (IActionResult) this.View((object) new List<SecurityBulletin>()
      {
        new SecurityBulletin("1.2", DateTime.Now.AddDays(-1.0), "Critical", "This update addresses a critical security vulnerability that could allow remote code execution.", "/api/v1/downloads/helpfuldesk-1.2.zip"),
        new SecurityBulletin("1.1", DateTime.Now.AddMonths(-1), "Low", "Adds minor UI changes and improvements.", "/api/v1/downloads/helpfuldesk-1.1.zip"),
        new SecurityBulletin("1.0", DateTime.Now.AddMonths(-3), "Low", "This initial update addresses minor security concerns and some bug fixes.", "/api/v1/downloads/helpfuldesk-1.0.zip")
      });
    }
  }
}
