﻿// Decompiled with JetBrains decompiler
// Type: HelpfulDesk.Models.ErrorViewModel
// Assembly: HelpfulDesk, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 493C75FD-F008-4902-AD1A-3BAC4993AB49
// Assembly location: Y:\huntress2024\web\helpful_desk\helpfuldesk-1.1\HelpfulDesk.dll

#nullable enable
namespace HelpfulDesk.Models
{
  public class ErrorViewModel
  {
    public string RequestId { get; set; }

    public bool ShowRequestId => !string.IsNullOrEmpty(this.RequestId);

    public string ExceptionMessage { get; set; }

    public int StatusCode { get; set; }
  }
}
