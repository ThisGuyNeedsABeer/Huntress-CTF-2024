﻿// Decompiled with JetBrains decompiler
// Type: HelpfulDesk.Models.SecurityBulletin
// Assembly: HelpfulDesk, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 493C75FD-F008-4902-AD1A-3BAC4993AB49
// Assembly location: Y:\huntress2024\web\helpful_desk\helpfuldesk-1.1\HelpfulDesk.dll

using System;

#nullable enable
namespace HelpfulDesk.Models
{
  public class SecurityBulletin
  {
    public string Version { get; set; }

    public DateTime ReleaseDate { get; set; }

    public string Severity { get; set; }

    public string Description { get; set; }

    public string DownloadLink { get; set; }

    public SecurityBulletin(
      string version,
      DateTime releaseDate,
      string severity,
      string description,
      string downloadLink)
    {
      this.Version = version;
      this.ReleaseDate = releaseDate;
      this.Severity = severity;
      this.Description = description;
      this.DownloadLink = downloadLink;
    }
  }
}
