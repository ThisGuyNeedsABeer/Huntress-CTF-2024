﻿// Decompiled with JetBrains decompiler
// Type: HelpfulDesk.Models.FileItem
// Assembly: HelpfulDesk, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 493C75FD-F008-4902-AD1A-3BAC4993AB49
// Assembly location: Y:\huntress2024\web\helpful_desk\helpfuldesk-1.1\HelpfulDesk.dll

using System.Collections.Generic;

#nullable enable
namespace HelpfulDesk.Models
{
  public class FileItem
  {
    public string Name { get; set; }

    public bool IsDirectory { get; set; }

    public List<FileItem> Children { get; set; } = new List<FileItem>();
  }
}
