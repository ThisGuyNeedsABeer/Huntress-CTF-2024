﻿// Decompiled with JetBrains decompiler
// Type: HelpfulDesk.Services.AuthenticationService
// Assembly: HelpfulDesk, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 493C75FD-F008-4902-AD1A-3BAC4993AB49
// Assembly location: Y:\huntress2024\web\helpful_desk\helpfuldesk-1.1\HelpfulDesk.dll

using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;

#nullable enable
namespace HelpfulDesk.Services
{
  public class AuthenticationService
  {
    private readonly string _filePath = "credentials.json";

    public AuthenticationService.AuthenticationResult ValidateUser(string username, string password)
    {
      foreach (AuthenticationService.UserCredentials userCredentials in JsonConvert.DeserializeObject<List<AuthenticationService.UserCredentials>>(File.ReadAllText(this._filePath)))
      {
        if (userCredentials.Username == username && userCredentials.Password == password)
          return new AuthenticationService.AuthenticationResult()
          {
            IsAuthenticated = true,
            IsAdmin = userCredentials.IsAdmin
          };
      }
      return new AuthenticationService.AuthenticationResult()
      {
        IsAuthenticated = false,
        IsAdmin = false
      };
    }

    public class UserCredentials
    {
      public string Username { get; set; }

      public string Password { get; set; }

      public bool IsAdmin { get; set; }
    }

    public class AuthenticationResult
    {
      public bool IsAuthenticated { get; set; }

      public bool IsAdmin { get; set; }
    }
  }
}
